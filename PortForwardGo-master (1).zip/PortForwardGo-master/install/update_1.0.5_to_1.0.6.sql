INSERT INTO
  `payments` (`id`, `type`, `name`, `value`)
VALUES
  (NULL, 'mgate', 'enable', 'false'),
  (NULL, 'mgate', 'display', 'MGate'),
  (NULL, 'mgate', 'fee', ''),
  (NULL, 'mgate', 'api', ''),
  (NULL, 'mgate', 'app_id', ''),
  (NULL, 'mgate', 'app_secret', '');

INSERT INTO
  `settings` (`id`, `name`, `value`)
VALUES
  (NULL, 'version', '');
